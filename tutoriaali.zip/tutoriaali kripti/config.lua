Config = {}

--    {
--        coords = {x = 1, y = 1, z = 1, h = },
--        title = "",
--        text = "",
--        image = "" 
--    }


Config.Spots = {
    {
        coords = {x = -227.97676086426, y = -1011.3962402344, z = 32.353552627563, h = 37.77},
        title = "Työkkäri/Työkeskus",
        text = "Täälä voit hakea työn joka ei ole whitelistattu eli jos haluat whitelistatulle työlle niin hae discordista.",
        image = "images/jobcenter.png" 
    },
    {
        coords = {x = -95.83366394043, y = -1141.2780761719, z = 30.936989593506, h = 310.42},
        title = "Autokauppa",
        text = "täältä voit ostaa ajoneuvon rahoilla jota olet saanut töistä.",
        image = "images/cardealer.png" 
    },
    {
        coords = {x = 398.56915283203, y = -951.15563964844, z = 34.322616577148, h = 223.53907775879},
        title = "Poliisiasema",
        text = "Täällä voit ilmoittaa rikoksesta mutta jos olet rikollinen ÄLÄ MENE ;D.",
        image = "images/policestation.png" 
    }
}