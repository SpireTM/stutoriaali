resource_manifest_version "44febabe-d386-4d18-afbe-5e627f4af937"

client_scripts {
    "config.lua",
    "clointti/client.lua"
}

server_scripts {
	'@mysql-async/lib/MySQL.lua',
	'sorvori/server.lua'
}

ui_page "html/index.html"

files {
    'html/index.html',
    'html/index.js',
    'html/index.css',
    'html/reset.css',
    'html/images/jobcenter.png',
    'html/images/cardealer.png',
    'html/images/policestation.png',
    'html/images/ammunation.png',
    'html/1.jpg'
}
