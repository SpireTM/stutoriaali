CREATE TABLE IF NOT EXISTS `s_tutoriaali` (
  `identifier` varchar(50) DEFAULT NULL,
  `times` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
