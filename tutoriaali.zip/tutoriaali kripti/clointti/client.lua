local display = false

function SetDisplay(bool)
    display = bool
    SendNUIMessage({
        type = "ui",
        status = bool,
    })
end

RegisterCommand('addtutoriaali', function(source, args, rawCommand)
	local kordit = GetEntityCoords(PlayerPedId())
	local suunta = GetEntityHeading(PlayerPedId())
	local zz = kordit.z + 5
	SendNUIMessage({
		kordit = "x = "..kordit.x..", y = "..kordit.y..", z = "..zz..", h = "..suunta..""
	})
	print('Coords kopioitiin leikepöydälle onnistuneesti.')
end)

RegisterCommand("tutoriaali", function(source, args)
    TriggerServerEvent('s_tutoriaali:tarkista')
end)

RegisterNetEvent('s_tutoriaali:aloita')
AddEventHandler('s_tutoriaali:aloita', function()
    SetDisplay(true)
    local playerped = GetPlayerPed(-1)
    FreezeEntityPosition(playerped, true)
    SetEntityVisible(playerped, false)
    SetFollowPedCamViewMode(4)
    local before = GetEntityCoords(playerped, true)
    for i = 1, #Config.Spots do
        SetEntityCoords(playerped, Config.Spots[i].kordit.x, Config.Spots[i].kordit.y, Config.Spots[i].kordit.z)
        SetGameplayCamRelativeHeading(0.0)
        SetEntityHeading(playerped, Config.Spots[i].kordit.h)
        SendNUIMessage({
            type = "paivita",
            table = Config.Spots[i]
        })
        Citizen.Wait(10000)
    end
    FreezeEntityPosition(playerped, false)
    SetEntityCoords(playerped, before.x, before.y, before.z)
    SetEntityVisible(playerped, true)
    SetFollowPedCamViewMode(1)
    SetDisplay(false)
end)


