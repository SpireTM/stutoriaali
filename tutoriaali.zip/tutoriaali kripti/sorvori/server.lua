RegisterServerEvent('s-tutoriaali:tarkista')
AddEventHandler('s-tutoriaali:tarkista', function()
    local identifier = GetPlayerIdentifiers(source)[1]
    local _src = source
    MySQL.Async.fetchScalar('SELECT times FROM s_tutoriaali WHERE identifier = @identifier', {
		['@identifier'] = identifier
    }, function(result)
        if result == nil then
            MySQL.Sync.execute("INSERT INTO s_tutoriaali (`identifier`, `times`) VALUES (@identifier, @times)",{['@identifier'] = identifier, ['@times'] = 1})
            TriggerClientEvent('s-tutoriaali:aloita', _src)
        elseif tonumber(result) < 2 then
            MySQL.Sync.execute("UPDATE s_tutoriaali SET times =@times WHERE identifier=@identifier",{['@identifier'] = identifier, ['@times'] = tonumber(result) + 1})
            TriggerClientEvent('s-tutoriaali:aloita', _src)
        else
            TriggerClientEvent('esx:showNotification', _src, "Olet katsellut tutoriaalin jo kahdesti.")
        end
	end)
end)


